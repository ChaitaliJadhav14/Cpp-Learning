#include<iostream>
using namespace std;
void welcome();//prototype:inform compiler that there is a welcome function with a certain signature. 

int main()
{
cout<<"\nMain Script starts.";
//call
welcome();//noone knows welcome
cout<<"\nMain Script ends.";
}
void welcome()
{
	cout<<"\nhi welcome here a function ...";
}