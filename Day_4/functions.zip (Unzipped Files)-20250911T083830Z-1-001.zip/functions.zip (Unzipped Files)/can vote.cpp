#include<iostream>
using namespace std;
//can vote ?
/*
Nesting of functions is where one function internally calls another function. 
write a function can_vote(int age) which will return true if 18 or above else false
write function register which reads name ,gender,age and prints
name:<name> gender:<gender> age:<age> can vote or can not vote(done by can_vote())
*/
bool can_vote(int age)
{
	if(age>=18)
		return true;
	else
		return false;
}
void register_person(string name,string gender,int age)
{
	cout<<"\nName:"<<name;
	cout<<"\nGender:"<<gender;
	cout<<"\nAge:"<<age;
	if(can_vote(age))
		cout<<"\nCan vote";
	else
		cout<<"\nCan not vote";
	
}


int main() {
	register_person("abcd","male",9);
    return 0;
}