#include<iostream>
using namespace std;
//Write two functions: 90INR is 1 USD
//1USD_to_INR 
//2 INR_to_USD. 
//Ask amount from the user. 
//Then ask either one to be selected 1.usd-->inr     or inr-->usd and print the result.
double USD_to_INR(double usd) {
    return usd * 90;
}

double INR_to_USD(double inr) {
    return inr / 90;
}

int main() {
    int choice;
    double amount, result;
    cout << "Enter amount: ";
    cin >> amount;
    cout << "Choose conversion: 1. USD to INR  2. INR to USD: ";
    cin >> choice;
    if (choice == 1) {
        cout << "In INR: " << USD_to_INR(amount) << endl;
    } else if (choice == 2) {
        cout << "In USD: " << INR_to_USD(amount)<< endl;
    } else {
        cout << "Invalid choice" << endl;
    }
    return 0;
}