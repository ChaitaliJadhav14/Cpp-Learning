#include<iostream>
using namespace std;
//Overload area 
//Area single parameter(r) will print the area of a circle. 
//Area two parameters(l,b) will print the area of a rectangle. 
//Program should read:
//1. Radius, call appropriate area.
//2. Length and breadth, call appropriate area.
double area(double r) {
    return 3.14 * r * r;
}

double area(double l, double b) {
    return l * b;
}

int main() {
    double r, l, b;
    cout << "Enter radius: ";
    cin >> r;
    cout << "Area of circle: " << area(r) << endl;
    cout << "Enter length and breadth: ";
    cin >> l >> b;
    cout << "Area of rectangle: " << area(l, b) << endl;
    return 0;
}