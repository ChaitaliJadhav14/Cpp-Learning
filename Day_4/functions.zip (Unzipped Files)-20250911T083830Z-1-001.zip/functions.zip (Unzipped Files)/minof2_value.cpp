#include<iostream>
using namespace std;

void min(int no1,int no2)
{
	if(no1<no2)
		cout<<"\n"<<no1<<" is minimum";
	else	
		cout<<"\n"<<no2<<" is minimum";
}
int main()
{
int no1,no2;
cout<<"\nEnter 2 numbers:\n";
cin>>no1>>no2;
min(no1,no2);

}
