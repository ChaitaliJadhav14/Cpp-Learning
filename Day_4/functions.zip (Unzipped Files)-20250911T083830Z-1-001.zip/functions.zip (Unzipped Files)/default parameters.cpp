#include<iostream>
using namespace std;
void returns(float amount,float roi=7)//Default values should always be right-handed. 
	{
		cout<<"\nAmount:"<<amount<<" @ rate of interest"<<roi<<"% Total will be:"<<amount+(amount*roi/100);
}
int main() {
 	returns(10000);
 	returns(10000,18);
    return 0;
}