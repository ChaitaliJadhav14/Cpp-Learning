#include<iostream>
using namespace std;
void welcome()//not accepting not returning
{
	cout<<"\nhi welcome here a function ...";
}
void welcome(string name)//not accepting not returning
{
	cout<<"\nhi "<<name<<" welcome here...";
}
int main()
{
cout<<"\nMain Script starts.";
//call
welcome();//noone knows welcome
welcome("AIT");
cout<<"\nMain Script ends.";
}
