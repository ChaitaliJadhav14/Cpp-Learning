#include<iostream>
using namespace std;

//Create function intro accepting name of a person, nationality, and state.
//Name of a person is compulsory
//but default parameters for nationality is India and state is Maharashtra.

//Create three use cases:
//1. Which gives all information
//2. Which only gives NAME and State
//3. Which only gives NEM 
void intro(string name, string state = "Maharashtra", string nationality = "India") {
    cout << "Name: " << name << endl;
    cout << "State: " << state << endl;
    cout << "Nationality: " << nationality << endl;
    cout << endl;
}

int main() {
    intro("Rahul", "California", "USA");
    intro("Radhika", "Rajasthan");
    intro("Amar");
    return 0;
}